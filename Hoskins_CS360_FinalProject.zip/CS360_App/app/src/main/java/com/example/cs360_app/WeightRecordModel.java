package com.example.cs360_app;

public class WeightRecordModel {
    private String date;
    private String weight;
    int image;

    // Constructor for WeightRecordModel
    public WeightRecordModel(String date, String weight, int image) {
        this.date = date;
        this.weight = weight;
        this.image = image;
    }
    // == Getters and Setters == //
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }
}
