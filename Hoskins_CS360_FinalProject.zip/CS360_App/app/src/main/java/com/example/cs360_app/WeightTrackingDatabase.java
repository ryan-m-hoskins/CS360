package com.example.cs360_app;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;

@Database(entities = {WeightRecordEntity.class, UserEntity.class, TargetWeightEntity.class}, version = 3)
public abstract class WeightTrackingDatabase extends RoomDatabase {
    public abstract WeightRecordDAO weightRecordDAO();
    public abstract UserDAO userDAO();
    public abstract TargetWeightDAO targetWeightDAO();

    private static WeightTrackingDatabase INSTANCE;

    public static WeightTrackingDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context, WeightTrackingDatabase.class, "weight_tracking_db").fallbackToDestructiveMigration().build();
        }
        return INSTANCE;
    }

    @NonNull
    @Override
    protected SupportSQLiteOpenHelper createOpenHelper(@NonNull DatabaseConfiguration databaseConfiguration) {
        return null;
    }

    @NonNull
    @Override
    protected InvalidationTracker createInvalidationTracker() {
        return null;
    }
}
